<?php
 $db = "webtech";
	$conn = mysqli_connect("localhost", "root","work@hard") or die(mysql_error()); //Connect to server
	mysqli_select_db($conn, $db) or die("Cannot connect to database"); //Connect to database
	$query = mysqli_query($conn, "Select * from tbl_contact"); //Query the users table
	
?>
<html>
<head><title>Listing Information</title></head>

<body>
<table border="1">
	<tr>
		<th>Full Name</th>
		<th>Email</th>
		<th>Address</th>
	</tr>
<?php 
     while($row = mysqli_fetch_array($query)) //display all rows from query
	{

?>		  
	<tr>
		<th><?php echo $row['fullname']; ?></th>
		<th><?php echo $row['email']; ?></th>
		<th><?php echo $row['address']; ?></th>
	</tr>
	<?php } ?>


</table>

<a href="index.php">Go back to Contact Us Page</a>

</body>
</html>