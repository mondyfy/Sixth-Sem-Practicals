<html>
	<head>
		<title>Contact Us Page</title>
	</head>
	<body>
		<h2>Contact Us</h2>
		
		<form action="index.php" method="post" id="contact_form">
			Full Name: <input type="text" name="fullname" required="required"/> <br/>
			Email: <input type="text" name="email" required="required" /> <br/>
			Address:<textarea id="address" name="address" rows="5" cols="40"></textarea><br><br>
			<input type="submit" value="Register"/>
			
		</form>
		
	</body>
</html>

<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){
	$fullname = $_POST['fullname'];
	$email = $_POST['email'];
	$address = $_POST['address'];
	
	
    $bool = true;
    $db = "webtech";
	$conn = mysqli_connect("localhost", "root","work@hard") or die(mysql_error()); //Connect to server
	mysqli_select_db($conn, $db) or die("Cannot connect to database"); //Connect to database
	$query = mysqli_query($conn, "Select * from tbl_contact"); //Query the users table
	while($row = mysqli_fetch_array($query)) //display all rows from query
	{
		$table_users = $row['fullname']; // the first username row is passed on to $table_users, and so on until the query is finished
		if($fullname == $table_users) // checks if there are any matching fields
		{
			$bool = false; // sets bool to false
			Print '<script>alert("Username has been taken!");</script>'; //Prompts the user
			Print '<script>window.location.assign("index.php");</script>'; // redirects to register.php
		}
	}
	if($bool) // checks if bool is true
	{
		mysqli_query($conn, "INSERT INTO tbl_contact(fullname, email, address) VALUES ('$fullname','$email', '$address')"); //Inserts the value to table users
		Print '<script>alert("Successfully Registered!");</script>'; // Prompts the user
		Print '<script>window.location.assign("list.php");</script>'; // redirects to register.php
	}
}
?>